# chat.py
# Interactive chat with your trained model
# Supports temperature, top-k, and top-p (nucleus) sampling

import torch
import torch.nn.functional as F
import os

from config import ModelConfig
from model import ChatbotModel
from tokenizer import load_tokenizer, get_special_ids


# ── Sampling ──────────────────────────────────────────────────────────────────
def sample_next_token(logits: torch.Tensor, temperature: float = 0.8,
                      top_k: int = 50, top_p: float = 0.9) -> int:
    """
    Sample next token using temperature + top-k + top-p (nucleus) sampling.
    - temperature : higher = more creative, lower = more focused
    - top_k       : only consider top K tokens
    - top_p       : only consider tokens covering top P% probability mass
    """
    logits = logits / max(temperature, 1e-8)

    # Top-k
    if top_k > 0:
        top_vals = torch.topk(logits, min(top_k, logits.size(-1)))[0]
        logits[logits < top_vals[-1]] = float('-inf')

    # Top-p (nucleus)
    if top_p < 1.0:
        sorted_logits, sorted_idx = torch.sort(logits, descending=True)
        cumprobs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
        # Remove tokens above cumulative probability threshold
        remove = cumprobs - F.softmax(sorted_logits, dim=-1) > top_p
        sorted_logits[remove] = float('-inf')
        logits = torch.zeros_like(logits).scatter_(0, sorted_idx, sorted_logits)

    probs = F.softmax(logits, dim=-1)
    return torch.multinomial(probs, num_samples=1).item()


# ── Generate ──────────────────────────────────────────────────────────────────
@torch.no_grad()
def generate(model, tokenizer, special_ids: dict, prompt: str,
             max_new_tokens: int = 80, temperature: float = 0.8,
             top_k: int = 50, top_p: float = 0.9,
             device: str = "cuda") -> str:

    model.eval()
    sos_id = special_ids["sos"]
    eos_id = special_ids["eos"]

    inp_ids = tokenizer.encode(prompt.lower().strip()).ids
    tokens  = torch.tensor(
        [[sos_id] + inp_ids + [eos_id]], dtype=torch.long
    ).to(device)

    generated = []
    for _ in range(max_new_tokens):
        # Trim to max_seq_len if needed
        context = tokens[:, -model.cfg.max_seq_len:]
        logits  = model(context)[0, -1]   # last token logits

        next_id = sample_next_token(logits, temperature, top_k, top_p)

        if next_id == eos_id:
            break

        generated.append(next_id)
        tokens = torch.cat(
            [tokens, torch.tensor([[next_id]], device=device)], dim=1
        )

    if not generated:
        return "..."

    return tokenizer.decode(generated).strip()


# ── Load Model ────────────────────────────────────────────────────────────────
def load_model(cfg: ModelConfig):
    ckpt = torch.load(cfg.model_path, map_location=cfg.device, weights_only=True)

    # Restore config from checkpoint
    for key in ["vocab_size","d_model","n_heads","n_layers",
                "d_ff","max_seq_len","dropout"]:
        setattr(cfg, key, ckpt[key])

    model = ChatbotModel(cfg).to(cfg.device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    return model


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    cfg = ModelConfig()

    if not os.path.exists(cfg.model_path):
        print(f"\n  ❌  No model found at: {cfg.model_path}")
        print("  👉  Train first: python train.py\n")
        return

    print("\n" + "═" * 50)
    print("  🤖  Chatbot")
    print("═" * 50)

    tokenizer   = load_tokenizer(cfg.tokenizer_path)
    special_ids = get_special_ids(tokenizer)
    model       = load_model(cfg)

    print(f"  Params   : {model.count_params():,}")
    print(f"  Vocab    : {cfg.vocab_size:,}")
    print(f"  Device   : {cfg.device}")
    print("═" * 50)
    print("  Commands: 'quit' exit | 'temp X' set temperature")
    print("            'reset' clear history")
    print("═" * 50 + "\n")

    temperature = 0.8
    top_k       = 50
    top_p       = 0.9

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Goodbye! 👋")
            break

        if not user_input:
            continue

        # Commands
        if user_input.lower() in ("quit", "exit", "bye"):
            print("Bot: Goodbye! Take care 👋")
            break

        if user_input.lower().startswith("temp "):
            try:
                temperature = float(user_input.split()[1])
                print(f"  ✅  Temperature set to {temperature}")
            except:
                print("  Usage: temp 0.8  (0.1 = focused, 1.5 = creative)")
            continue

        if user_input.lower() == "reset":
            print("  ✅  History cleared")
            continue

        # Generate response
        response = generate(
            model, tokenizer, special_ids,
            user_input,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            device=cfg.device,
        )
        print(f"Bot: {response}\n")


if __name__ == "__main__":
    main()
