# prepare_data.py
# Downloads DailyDialog dataset and converts to training format
# Run ONCE before training: python prepare_data.py

import os
import json
import re


def clean(text: str) -> str:
    """Normalize text: lowercase, fix spacing, strip junk."""
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)               # collapse whitespace
    text = re.sub(r" ([.,!?;:])", r"\1", text)      # fix space before punctuation
    return text


def prepare():
    os.makedirs("data", exist_ok=True)
    out_path = "data/conversations.jsonl"

    print("═" * 55)
    print("  📥  Preparing Training Data")
    print("═" * 55)

    # Install datasets if needed
    try:
        from datasets import load_dataset
    except ImportError:
        print("  Installing datasets library...")
        os.system("pip install datasets -q")
        from datasets import load_dataset

    print("  Downloading DailyDialog...")
    try:
        ds = load_dataset("daily_dialog", trust_remote_code=True)
    except Exception as e:
        print(f"  ❌  Download failed: {e}")
        print("  Try: pip install datasets --upgrade")
        return

    count   = 0
    skipped = 0

    with open(out_path, "w", encoding="utf-8") as f:
        for split in ["train", "validation", "test"]:
            if split not in ds:
                continue
            for dialog in ds[split]["dialog"]:
                for i in range(len(dialog) - 1):
                    inp = clean(dialog[i])
                    out = clean(dialog[i + 1])

                    # Quality filters
                    if len(inp) < 3 or len(out) < 3:
                        skipped += 1
                        continue
                    if len(inp) > 300 or len(out) > 300:
                        skipped += 1
                        continue
                    if inp == out:
                        skipped += 1
                        continue

                    f.write(json.dumps({"input": inp, "output": out}) + "\n")
                    count += 1

    print(f"  ✅  {count:,} pairs saved  →  {out_path}")
    print(f"  ⚠️   {skipped:,} pairs skipped (too short/long/duplicate)")
    print("─" * 55)

    # Preview
    print("  📄  Sample pairs:")
    with open(out_path) as f:
        for i, line in enumerate(f):
            if i >= 4:
                break
            item = json.loads(line)
            print(f"  [{i+1}] IN : {item['input'][:70]}")
            print(f"       OUT: {item['output'][:70]}")
            print()

    print("═" * 55)
    print("  ✅  Done! Now run: python train.py")
    print("═" * 55)


if __name__ == "__main__":
    prepare()
