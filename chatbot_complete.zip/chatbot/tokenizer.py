# tokenizer.py
# BPE tokenizer — trained on your data, saveable, HuggingFace-compatible format

import json
import os


SPECIAL_TOKENS = ["<pad>", "<sos>", "<eos>", "<unk>"]
PAD_ID = 0
SOS_ID = 1
EOS_ID = 2
UNK_ID = 3


def train_tokenizer(data_path: str, vocab_size: int = 8000, save_path: str = "tokenizer.json"):
    try:
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import ByteLevel
        from tokenizers.decoders import ByteLevel as ByteLevelDecoder
    except ImportError:
        os.system("pip install tokenizers -q")
        from tokenizers import Tokenizer
        from tokenizers.models import BPE
        from tokenizers.trainers import BpeTrainer
        from tokenizers.pre_tokenizers import ByteLevel
        from tokenizers.decoders import ByteLevel as ByteLevelDecoder

    # Collect all text
    texts = []
    with open(data_path, encoding="utf-8") as f:
        for line in f:
            item = json.loads(line.strip())
            texts.append(item["input"])
            texts.append(item["output"])

    # Write temp corpus
    corpus_path = "temp_corpus.txt"
    with open(corpus_path, "w", encoding="utf-8") as f:
        f.write("\n".join(texts))

    # Build BPE tokenizer with ByteLevel (same as GPT-2 — HuggingFace compatible)
    tokenizer = Tokenizer(BPE(unk_token="<unk>"))
    tokenizer.pre_tokenizer = ByteLevel(add_prefix_space=False)
    tokenizer.decoder = ByteLevelDecoder()

    trainer = BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=SPECIAL_TOKENS,
        min_frequency=2,
        show_progress=True,
    )
    tokenizer.train([corpus_path], trainer)
    tokenizer.save(save_path)
    os.remove(corpus_path)

    actual = tokenizer.get_vocab_size()
    print(f"  Tokenizer trained  →  vocab: {actual:,} tokens")
    return tokenizer


def load_tokenizer(path: str = "tokenizer.json"):
    from tokenizers import Tokenizer
    return Tokenizer.from_file(path)


def get_special_ids(tokenizer) -> dict:
    return {
        "pad": tokenizer.token_to_id("<pad>") or PAD_ID,
        "sos": tokenizer.token_to_id("<sos>") or SOS_ID,
        "eos": tokenizer.token_to_id("<eos>") or EOS_ID,
        "unk": tokenizer.token_to_id("<unk>") or UNK_ID,
    }
