# model.py
# Modern transformer using:
#   - RoPE positional encoding  (no fixed pos embeddings — better generalization)
#   - RMSNorm                   (faster than LayerNorm, used in LLaMA/Mistral)
#   - SwiGLU activation         (used in LLaMA/PaLM — better than GELU)
#   - Weight tying              (input embedding = output projection)
#   - Flash-attention ready     (drops in when available)
# This architecture mirrors LLaMA-style models — easy HuggingFace export later.

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Optional


# ── RMSNorm ──────────────────────────────────────────────────────────────────
class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization (faster than LayerNorm)."""
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps   = eps
        self.scale = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rms = x.pow(2).mean(-1, keepdim=True).add(self.eps).sqrt()
        return self.scale * (x / rms)


# ── Rotary Positional Encoding (RoPE) ────────────────────────────────────────
def precompute_rope(dim: int, max_seq_len: int, base: int = 10000) -> torch.Tensor:
    """Precompute RoPE frequencies."""
    theta = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
    pos   = torch.arange(max_seq_len).float()
    freqs = torch.outer(pos, theta)
    return torch.polar(torch.ones_like(freqs), freqs)  # complex


def apply_rope(x: torch.Tensor, freqs: torch.Tensor) -> torch.Tensor:
    """Apply RoPE to query or key tensor."""
    T    = x.shape[2]
    x_c  = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    x_r  = torch.view_as_real(x_c * freqs[:T].unsqueeze(0).unsqueeze(0))
    return x_r.flatten(-2).type_as(x)


# ── SwiGLU Feed-Forward ───────────────────────────────────────────────────────
class SwiGLU(nn.Module):
    """SwiGLU feed-forward block (used in LLaMA, PaLM)."""
    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.w1   = nn.Linear(d_model, d_ff, bias=False)
        self.w2   = nn.Linear(d_ff, d_model, bias=False)
        self.w3   = nn.Linear(d_model, d_ff, bias=False)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # SwiGLU: swish(W1·x) ⊙ (W3·x), then project back
        return self.drop(self.w2(F.silu(self.w1(x)) * self.w3(x)))


# ── Multi-Head Attention with RoPE ───────────────────────────────────────────
class Attention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1,
                 max_seq_len: int = 256):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.n_heads = n_heads
        self.d_k     = d_model // n_heads

        self.Wq   = nn.Linear(d_model, d_model, bias=False)
        self.Wk   = nn.Linear(d_model, d_model, bias=False)
        self.Wv   = nn.Linear(d_model, d_model, bias=False)
        self.Wo   = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)

        # Precompute RoPE and register as buffer (moves with .to(device))
        freqs = precompute_rope(self.d_k, max_seq_len)
        self.register_buffer("freqs", freqs)

        # Causal mask
        mask = torch.tril(torch.ones(max_seq_len, max_seq_len, dtype=torch.bool))
        self.register_buffer("causal_mask", mask)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape

        Q = self.Wq(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)
        K = self.Wk(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)
        V = self.Wv(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)

        # Apply RoPE to Q and K
        Q = apply_rope(Q, self.freqs)
        K = apply_rope(K, self.freqs)

        # Try Flash Attention first (PyTorch 2.0+), fall back to manual
        try:
            out = F.scaled_dot_product_attention(
                Q, K, V,
                attn_mask=None,
                dropout_p=self.drop.p if self.training else 0.0,
                is_causal=True,
            )
        except Exception:
            scores = (Q @ K.transpose(-2, -1)) / math.sqrt(self.d_k)
            scores = scores.masked_fill(~self.causal_mask[:T, :T], float('-inf'))
            attn   = self.drop(torch.softmax(scores, dim=-1))
            out    = attn @ V

        out = out.transpose(1, 2).contiguous().view(B, T, C)
        return self.Wo(out)


# ── Transformer Block ─────────────────────────────────────────────────────────
class TransformerBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int,
                 dropout: float = 0.1, max_seq_len: int = 256):
        super().__init__()
        self.attn   = Attention(d_model, n_heads, dropout, max_seq_len)
        self.ff     = SwiGLU(d_model, d_ff, dropout)
        self.norm1  = RMSNorm(d_model)
        self.norm2  = RMSNorm(d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Pre-norm architecture (more stable than post-norm)
        x = x + self.attn(self.norm1(x))
        x = x + self.ff(self.norm2(x))
        return x


# ── Main Model ────────────────────────────────────────────────────────────────
class ChatbotModel(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg     = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.d_model, padding_idx=0)
        self.drop    = nn.Dropout(cfg.dropout)
        self.blocks  = nn.ModuleList([
            TransformerBlock(
                cfg.d_model, cfg.n_heads, cfg.d_ff,
                cfg.dropout, cfg.max_seq_len
            )
            for _ in range(cfg.n_layers)
        ])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)

        # Weight tying — improves quality and reduces parameters
        self.head.weight = self.tok_emb.weight

        # Initialize weights (GPT-2 style)
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.drop(self.tok_emb(x))
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        return self.head(x)

    def count_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def save_pretrained(self, save_dir: str):
        """Save in HuggingFace-compatible format for future export."""
        import os, json
        os.makedirs(save_dir, exist_ok=True)
        torch.save(self.state_dict(), os.path.join(save_dir, "pytorch_model.bin"))
        config_dict = {
            "model_type":   self.cfg.model_type,
            "vocab_size":   self.cfg.vocab_size,
            "d_model":      self.cfg.d_model,
            "n_heads":      self.cfg.n_heads,
            "n_layers":     self.cfg.n_layers,
            "d_ff":         self.cfg.d_ff,
            "max_seq_len":  self.cfg.max_seq_len,
            "dropout":      self.cfg.dropout,
            "architectures": ["ChatbotModel"],
        }
        with open(os.path.join(save_dir, "config.json"), "w") as f:
            json.dump(config_dict, f, indent=2)
        print(f"  ✅  Model saved in HF format → {save_dir}/")
