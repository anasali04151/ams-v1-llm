# download.py
# Zips the chatbot folder and downloads it
# Run in a Colab NOTEBOOK CELL (not terminal) for auto-download
# Or run in terminal — it will tell you where the zip is

import os
import shutil

FOLDER   = "/content/chatbot"
ZIP_OUT  = "/content/chatbot_backup"

required = [
    "model.py", "train.py", "chat.py", "config.py",
    "dataset.py", "tokenizer.py", "prepare_data.py",
    "chatbot_model.pt", "tokenizer.json",
]
optional = ["checkpoint.pt", "training_log.jsonl", "model_config.json"]

print("═" * 50)
print("  📦  Chatbot Backup")
print("═" * 50)

all_good = True
for f in required:
    path = os.path.join(FOLDER, f)
    if os.path.exists(path):
        kb = os.path.getsize(path) / 1024
        print(f"  ✅  {f:<28} {kb:>8.1f} KB")
    else:
        print(f"  ❌  {f:<28} MISSING")
        all_good = False

for f in optional:
    path = os.path.join(FOLDER, f)
    if os.path.exists(path):
        kb = os.path.getsize(path) / 1024
        print(f"  📎  {f:<28} {kb:>8.1f} KB  (optional)")

print("─" * 50)
if not all_good:
    print("  ⚠️  Some required files missing — zipping anyway")

print("  🔄  Zipping...")
shutil.make_archive(ZIP_OUT, "zip", "/content", "chatbot")
zip_path = ZIP_OUT + ".zip"
mb = os.path.getsize(zip_path) / (1024 * 1024)
print(f"  ✅  chatbot_backup.zip created  ({mb:.1f} MB)")
print("═" * 50)

# Try Colab download — works only inside a notebook cell
try:
    from google.colab import files
    print("  ⬇️   Downloading...")
    files.download(zip_path)
except Exception:
    print(f"\n  📁  Zip is at: {zip_path}")
    print("  To download, run this in a Colab notebook cell:")
    print("      from google.colab import files")
    print(f"      files.download('{zip_path}')")
    print("\n  Or copy to Google Drive:")
    print("      from google.colab import drive")
    print("      drive.mount('/content/drive')")
    print("      import shutil")
    print(f"      shutil.copy('{zip_path}', '/content/drive/MyDrive/')")
