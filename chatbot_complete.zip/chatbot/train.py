# train.py
# Modern training loop with:
#   - Mixed precision (AMP)  — faster on T4/A100/H100
#   - Cosine LR schedule     — better convergence than transformer schedule
#   - Warmup                 — stable early training
#   - Gradient clipping      — prevents exploding gradients
#   - Auto checkpoint        — saves every epoch, resumes automatically
#   - JSONL training log     — machine-readable loss history
#   - HuggingFace export     — saves model in HF format on stop

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import math
import time
import os
import json

from config import ModelConfig
from model import ChatbotModel
from dataset import ConversationDataset
from tokenizer import train_tokenizer, load_tokenizer, get_special_ids


# ── Learning Rate Schedule ────────────────────────────────────────────────────
def get_cosine_lr(step: int, total_steps: int, warmup_steps: int,
                  max_lr: float, min_lr: float = 1e-5) -> float:
    """Cosine decay with linear warmup. Industry standard."""
    if step < warmup_steps:
        return max_lr * (step / max(warmup_steps, 1))
    progress = (step - warmup_steps) / max(total_steps - warmup_steps, 1)
    cosine   = 0.5 * (1.0 + math.cos(math.pi * progress))
    return min_lr + (max_lr - min_lr) * cosine


# ── Checkpoint Save / Load ────────────────────────────────────────────────────
def save_checkpoint(model, optimizer, scaler, epoch, step,
                    best_loss, cfg, tokenizer, path: str):
    torch.save({
        "model_state":     model.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "scaler_state":    scaler.state_dict(),
        "epoch":           epoch,
        "step":            step,
        "best_loss":       best_loss,
        # Save all config fields as plain values
        "vocab_size":      cfg.vocab_size,
        "d_model":         cfg.d_model,
        "n_heads":         cfg.n_heads,
        "n_layers":        cfg.n_layers,
        "d_ff":            cfg.d_ff,
        "max_seq_len":     cfg.max_seq_len,
        "dropout":         cfg.dropout,
        "model_type":      cfg.model_type,
        "model_version":   cfg.model_version,
    }, path)
    tokenizer.save(cfg.tokenizer_path)


def load_checkpoint(path: str, model, optimizer, scaler, cfg):
    ckpt = torch.load(path, map_location=cfg.device, weights_only=True)
    model.load_state_dict(ckpt["model_state"])
    optimizer.load_state_dict(ckpt["optimizer_state"])
    scaler.load_state_dict(ckpt["scaler_state"])
    # Restore config
    for key in ["vocab_size","d_model","n_heads","n_layers",
                "d_ff","max_seq_len","dropout"]:
        setattr(cfg, key, ckpt[key])
    return ckpt["epoch"], ckpt["step"], ckpt["best_loss"]


# ── Training Log ──────────────────────────────────────────────────────────────
def log_epoch(log_path: str, data: dict):
    with open(log_path, "a") as f:
        f.write(json.dumps(data) + "\n")


# ── Main Train Function ───────────────────────────────────────────────────────
def train():
    cfg = ModelConfig()

    # ── Validate data ────────────────────────────────────────────────
    if not os.path.exists(cfg.data_path):
        print(f"\n  ❌  Dataset not found: {cfg.data_path}")
        print("  👉  Run first: python prepare_data.py\n")
        return

    # ── Tokenizer ────────────────────────────────────────────────────
    if os.path.exists(cfg.tokenizer_path):
        print("  Loading tokenizer...")
        tokenizer = load_tokenizer(cfg.tokenizer_path)
    else:
        print("  Training tokenizer...")
        tokenizer = train_tokenizer(cfg.data_path, cfg.vocab_size, cfg.tokenizer_path)
    cfg.vocab_size = tokenizer.get_vocab_size()
    special_ids    = get_special_ids(tokenizer)

    # ── Dataset ──────────────────────────────────────────────────────
    print("  Loading dataset...")
    dataset = ConversationDataset(
        cfg.data_path, tokenizer, special_ids, cfg.max_seq_len
    )

    # num_workers: 2 for T4 Colab, 4 for A100/H100
    num_workers = 2 if cfg.device == "cuda" else 0
    loader = DataLoader(
        dataset,
        batch_size=cfg.batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=(cfg.device == "cuda"),
        drop_last=True,
    )

    # ── Model ─────────────────────────────────────────────────────────
    model     = ChatbotModel(cfg).to(cfg.device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
        betas=(0.9, 0.95),
        eps=1e-8,
    )
    criterion = nn.CrossEntropyLoss(ignore_index=-100)

    # AMP scaler — fp16 on T4, bf16 on A100/H100
    use_amp  = (cfg.device == "cuda")
    amp_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    scaler   = torch.cuda.amp.GradScaler(enabled=use_amp)

    # ── Resume ───────────────────────────────────────────────────────
    start_epoch = 0
    step        = 0
    best_loss   = float('inf')

    if os.path.exists(cfg.checkpoint_path):
        print(f"\n  📂  Checkpoint found — resuming...")
        start_epoch, step, best_loss = load_checkpoint(
            cfg.checkpoint_path, model, optimizer, scaler, cfg
        )
        start_epoch += 1
        print(f"  ↪   From epoch {start_epoch + 1}  |  Best loss: {best_loss:.4f}")

    # ── Estimate total steps for LR schedule ─────────────────────────
    # Assume ~500 epochs max for schedule; it just flattens after
    estimated_total_steps = 500 * len(loader)
    batches_per_epoch     = len(loader)

    # ── Print header ─────────────────────────────────────────────────
    print("\n" + "═" * 68)
    print("  🚀  TRAINING  —  Ctrl+C to stop and save anytime")
    print("═" * 68)
    print(f"  Model         : {model.count_params():,} params")
    print(f"  Vocab         : {cfg.vocab_size:,} tokens")
    print(f"  Dataset       : {len(dataset):,} samples  ({batches_per_epoch} batches/epoch)")
    print(f"  Batch size    : {cfg.batch_size}")
    print(f"  Device        : {cfg.device}")
    print(f"  Precision     : {'bf16' if amp_dtype == torch.bfloat16 else 'fp16'} AMP")
    print(f"  Architecture  : RoPE + RMSNorm + SwiGLU  (LLaMA-style)")
    print("═" * 68)
    print(f"  {'Epoch':>6}  {'Loss':>7}  {'Pplx':>7}  {'LR':>9}  {'Time':>7}  Status")
    print(f"  {'─'*6}  {'─'*7}  {'─'*7}  {'─'*9}  {'─'*7}  {'─'*16}")

    history     = []
    train_start = time.time()
    epoch       = start_epoch

    try:
        while True:   # ── Infinite loop — Ctrl+C to stop ──────────────

            model.train()
            total_loss  = 0.0
            epoch_start = time.time()

            for batch_idx, (input_ids, label_ids) in enumerate(loader):
                input_ids = input_ids.to(cfg.device, non_blocking=True)
                label_ids = label_ids.to(cfg.device, non_blocking=True)

                # ── Forward with AMP ─────────────────────────────────
                with torch.cuda.amp.autocast(enabled=use_amp, dtype=amp_dtype):
                    logits = model(input_ids)
                    loss   = criterion(
                        logits.view(-1, cfg.vocab_size),
                        label_ids.view(-1),
                    )

                # ── Backward ─────────────────────────────────────────
                optimizer.zero_grad(set_to_none=True)
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
                scaler.step(optimizer)
                scaler.update()

                # ── Cosine LR update ─────────────────────────────────
                step += 1
                new_lr = get_cosine_lr(
                    step, estimated_total_steps,
                    cfg.warmup_steps, cfg.learning_rate
                )
                for pg in optimizer.param_groups:
                    pg["lr"] = new_lr

                total_loss += loss.item()

            # ── Epoch stats ──────────────────────────────────────────
            avg_loss   = total_loss / batches_per_epoch
            perplexity = math.exp(min(avg_loss, 10))
            epoch_time = time.time() - epoch_start
            current_lr = optimizer.param_groups[0]["lr"]
            history.append(avg_loss)

            # Status
            if avg_loss < best_loss:
                diff = best_loss - avg_loss
                if best_loss == float('inf'):
                    status = "✅ start"
                elif diff > 0.5:
                    status = "🔥 great drop!"
                elif diff > 0.1:
                    status = "✅ improving"
                else:
                    status = "📈 small gain"
                best_loss = avg_loss
                # Save best model
                save_checkpoint(model, optimizer, scaler, epoch, step,
                                best_loss, cfg, tokenizer, cfg.model_path)
            else:
                status = "⚠️  no improve"

            # Always save rolling checkpoint for resume
            save_checkpoint(model, optimizer, scaler, epoch, step,
                            best_loss, cfg, tokenizer, cfg.checkpoint_path)

            # Log to file
            log_epoch(cfg.log_path, {
                "epoch": epoch + 1, "loss": round(avg_loss, 4),
                "perplexity": round(perplexity, 2),
                "lr": round(current_lr, 8), "time_s": round(epoch_time, 1),
            })

            print(f"  {epoch+1:>6}  {avg_loss:>7.4f}  {perplexity:>7.2f}  "
                  f"{current_lr:>9.2e}  {epoch_time:>6.1f}s  {status}")

            # ── Milestone every 10 epochs ────────────────────────────
            if (epoch + 1) % 10 == 0:
                avg_10    = sum(history[-10:]) / min(10, len(history))
                elapsed   = time.time() - train_start
                trend     = history[-1] - history[-10] if len(history) >= 10 else 0
                print(f"  {'─'*66}")
                print(f"  📊  Milestone — Epoch {epoch+1}")
                print(f"      Avg loss  (last 10) : {avg_10:.4f}")
                print(f"      Best loss (all time): {best_loss:.4f}")
                print(f"      Loss trend (10 ep)  : {trend:+.4f}  "
                      f"({'improving ✅' if trend < 0 else 'stalling ⚠️'})")
                print(f"      Time elapsed        : {elapsed/60:.1f} min")
                if avg_10 > 4.0:
                    tip = "Still learning basics — keep going."
                elif avg_10 > 2.5:
                    tip = "Patterns emerging — try chatting soon."
                elif avg_10 > 1.5:
                    tip = "Good! Responses should make sense."
                else:
                    tip = "Excellent! Model is well trained."
                print(f"      💡 {tip}")
                if abs(trend) < 0.005 and avg_10 > 2.0:
                    print(f"      ⚠️  Loss is flat — consider stopping and")
                    print(f"          adjusting LR or adding more data.")
                print(f"  {'─'*66}")

            epoch += 1

    except KeyboardInterrupt:
        # ── Graceful stop ────────────────────────────────────────────
        total_time = time.time() - train_start
        print("\n\n" + "═" * 68)
        print("  🛑  STOPPED  (Ctrl+C)")
        print("═" * 68)
        print("  Saving...")
        save_checkpoint(model, optimizer, scaler, epoch, step,
                        best_loss, cfg, tokenizer, cfg.checkpoint_path)
        save_checkpoint(model, optimizer, scaler, epoch, step,
                        best_loss, cfg, tokenizer, cfg.model_path)

        # Also export HuggingFace format
        model.save_pretrained("hf_export")
        cfg.save("hf_export/model_config.json")

        print(f"  ✅  checkpoint.pt      →  resume anytime")
        print(f"  ✅  chatbot_model.pt   →  best weights")
        print(f"  ✅  hf_export/         →  HuggingFace format")
        print("─" * 68)
        print(f"  Epochs   : {epoch}")
        print(f"  Best loss: {best_loss:.4f}  |  Perplexity: {math.exp(min(best_loss,10)):.2f}")
        print(f"  Time     : {total_time/60:.1f} min")
        print("─" * 68)
        if best_loss < 1.5:
            verdict = "Excellent — model is well trained."
        elif best_loss < 2.5:
            verdict = "Good — responses should be coherent."
        elif best_loss < 4.0:
            verdict = "Okay — resume training for better quality."
        else:
            verdict = "High loss — need more data or more epochs."
        print(f"  📝 {verdict}")
        print("─" * 68)
        print("  💡 Resume:  python train.py")
        print("  💡 Chat  :  python chat.py")
        print("═" * 68 + "\n")


if __name__ == "__main__":
    train()
