# config.py
# HuggingFace-compatible config using dataclasses
# Easily upgrade by changing these values — no other file needs to change

from dataclasses import dataclass, asdict
import json
import os


@dataclass
class ModelConfig:
    # ── Architecture ─────────────────────────────────────────────────
    vocab_size    : int   = 8000      # grows after tokenizer training
    d_model       : int   = 256       # embedding dimension
    n_heads       : int   = 8         # attention heads (d_model must be divisible)
    n_layers      : int   = 6         # transformer blocks
    d_ff          : int   = 1024      # feed-forward inner dim (4 * d_model)
    max_seq_len   : int   = 256       # max tokens per sequence
    dropout       : float = 0.1       # dropout rate

    # ── Training ──────────────────────────────────────────────────────
    batch_size    : int   = 32        # T4: 32 | A100: 128 | H100: 256
    learning_rate : float = 3e-4      # AdamW base LR
    warmup_steps  : int   = 300       # LR warmup steps
    grad_clip     : float = 1.0       # gradient clipping
    weight_decay  : float = 0.01

    # ── Paths ─────────────────────────────────────────────────────────
    data_path     : str   = "data/conversations.jsonl"
    model_path    : str   = "chatbot_model.pt"
    checkpoint_path: str  = "checkpoint.pt"
    tokenizer_path: str   = "tokenizer.json"
    log_path      : str   = "training_log.jsonl"

    # ── Device ────────────────────────────────────────────────────────
    # "cuda" for T4/A100/H100 | "mps" for Mac | "cpu" for no GPU
    device        : str   = "cuda"

    # ── Model identity (for HuggingFace export) ───────────────────────
    model_type    : str   = "tiny_gpt"
    model_version : str   = "1.0.0"

    def save(self, path="model_config.json"):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)
        print(f"  Config saved → {path}")

    @classmethod
    def load(cls, path="model_config.json"):
        with open(path) as f:
            data = json.load(f)
        return cls(**data)

    def upgrade_for_gpu(self, gpu: str):
        """Quickly switch config for a bigger GPU."""
        presets = {
            "t4":   dict(batch_size=32,  d_model=256, n_layers=6,  d_ff=1024, warmup_steps=300),
            "a100": dict(batch_size=128, d_model=512, n_layers=8,  d_ff=2048, warmup_steps=500),
            "h100": dict(batch_size=256, d_model=768, n_layers=12, d_ff=3072, warmup_steps=1000),
        }
        gpu = gpu.lower()
        if gpu not in presets:
            print(f"  Unknown GPU '{gpu}'. Options: t4, a100, h100")
            return
        for k, v in presets[gpu].items():
            setattr(self, k, v)
        print(f"  ✅  Config upgraded for {gpu.upper()}")
        print(f"      batch={self.batch_size} | d_model={self.d_model} | "
              f"layers={self.n_layers} | d_ff={self.d_ff}")
