# dataset.py
import json
import torch
from torch.utils.data import Dataset


class ConversationDataset(Dataset):
    """
    Loads conversation pairs and formats them as:
        <sos> user_input <eos> bot_output <eos>
    The model learns to predict the next token at every position.
    Loss is only computed on the output side (labels for input side = -100).
    """

    def __init__(self, data_path: str, tokenizer, special_ids: dict,
                 max_len: int = 256):
        self.samples = []
        pad_id = special_ids["pad"]
        sos_id = special_ids["sos"]
        eos_id = special_ids["eos"]

        skipped = 0
        with open(data_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    skipped += 1
                    continue

                inp_ids = tokenizer.encode(item["input"]).ids
                out_ids = tokenizer.encode(item["output"]).ids

                # Full sequence: <sos> input <eos> output <eos>
                seq = [sos_id] + inp_ids + [eos_id] + out_ids + [eos_id]

                if len(seq) > max_len:
                    seq = seq[:max_len]

                pad_len    = max_len - len(seq)
                input_ids  = seq[:-1] + [pad_id] * pad_len
                target_ids = seq[1:]  + [pad_id] * pad_len

                # Mask input portion in labels so loss is only on output
                # -100 is ignored by CrossEntropyLoss
                input_len = len(inp_ids) + 1   # +1 for <sos>
                label_ids = (
                    [-100] * min(input_len, len(target_ids) - 1)
                    + target_ids[input_len:]
                )
                # Pad labels to same length
                label_ids = label_ids + [-100] * (max_len - 1 - len(label_ids))
                label_ids = label_ids[:max_len - 1]

                self.samples.append((
                    torch.tensor(input_ids,  dtype=torch.long),
                    torch.tensor(label_ids,  dtype=torch.long),
                ))

        if skipped:
            print(f"  ⚠️  Skipped {skipped} malformed lines")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]
