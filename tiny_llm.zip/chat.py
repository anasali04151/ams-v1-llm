"""
Interactive chat REPL — test your model at any checkpoint.

Usage
-----
    python chat.py --checkpoint checkpoints/step_001000.pt
    python chat.py --checkpoint checkpoints/step_001000.pt --strategy beam --beam-width 4
    python chat.py --checkpoint checkpoints/step_001000.pt --max-new 150 --temperature 0.7
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

import torch

from model import GPT
from config import ModelConfig
from tokenizer import Tokenizer
from generate import generate
from utils import count_params, human_size, load_checkpoint


BANNER = """
╔══════════════════════════════════════════════════════╗
║              Tiny LLM  ·  Interactive Chat           ║
║  Type your prompt and press Enter.                   ║
║  Commands: /quit  /strategy [sample|greedy|beam]     ║
║            /temp <float>  /topp <float>              ║
╚══════════════════════════════════════════════════════╝
"""


def load_model_from_checkpoint(ckpt_path: str, device: torch.device) -> tuple[GPT, Tokenizer, int]:
    ckpt = load_checkpoint(ckpt_path, device=str(device))

    # Rebuild model config from saved config dict
    model_cfg = ModelConfig(**ckpt["model_cfg"])
    model     = GPT(model_cfg).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    # Load tokenizer (path stored in train config)
    tok_path = ckpt.get("train_cfg", {}).get("tokenizer_path", "tokenizer")
    tokenizer = Tokenizer.load(tok_path)

    step = ckpt.get("step", 0)
    return model, tokenizer, step


def chat(args: argparse.Namespace) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\nLoading checkpoint: {args.checkpoint} ...")
    model, tokenizer, step = load_model_from_checkpoint(args.checkpoint, device)

    n_params = count_params(model)
    train_loss = None
    try:
        ckpt = load_checkpoint(args.checkpoint, device="cpu")
        train_loss = ckpt.get("train_loss")
    except Exception:
        pass

    print(BANNER)
    print(f"  Model       : {human_size(n_params)} parameters")
    print(f"  Checkpoint  : step {step:,}")
    print(f"  Train loss  : {train_loss:.4f}" if train_loss else "  Train loss  : n/a")
    print(f"  Device      : {device}")
    print(f"  Strategy    : {args.strategy}  temp={args.temperature}  top_p={args.top_p}")
    print()

    strategy    = args.strategy
    temperature = args.temperature
    top_p       = args.top_p

    while True:
        try:
            prompt = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not prompt:
            continue

        # ── Commands ──────────────────────────────────────────────────────────
        if prompt.startswith("/"):
            parts = prompt.split()
            cmd   = parts[0].lower()
            if cmd == "/quit":
                print("Bye!")
                break
            elif cmd == "/strategy" and len(parts) > 1:
                strategy = parts[1]
                print(f"  Strategy → {strategy}")
            elif cmd == "/temp" and len(parts) > 1:
                temperature = float(parts[1])
                print(f"  Temperature → {temperature}")
            elif cmd == "/topp" and len(parts) > 1:
                top_p = float(parts[1])
                print(f"  Top-p → {top_p}")
            else:
                print("  Unknown command. Try /quit, /strategy, /temp, /topp")
            continue

        # ── Generate ─────────────────────────────────────────────────────────
        prompt_ids = tokenizer.encode(prompt, add_special_tokens=True)

        try:
            new_ids = generate(
                model=model,
                prompt_ids=prompt_ids,
                max_new=args.max_new,
                temperature=temperature,
                top_p=top_p,
                strategy=strategy,
                beam_width=args.beam_width,
                eos_id=tokenizer.eos_id,
                device=device,
            )
        except Exception as e:
            print(f"  [generation error] {e}")
            continue

        response = tokenizer.decode(new_ids, skip_special_tokens=True)
        print(f"LLM: {response}\n")


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Chat with your tiny LLM")
    parser.add_argument(
        "--checkpoint", required=True,
        help="Path to checkpoint file, e.g. checkpoints/step_0001000.pt"
    )
    parser.add_argument("--max-new",    type=int,   default=200,     help="Max new tokens to generate")
    parser.add_argument("--temperature",type=float, default=0.8,     help="Sampling temperature (0=greedy)")
    parser.add_argument("--top-p",      type=float, default=0.9,     help="Nucleus (top-p) sampling threshold")
    parser.add_argument("--strategy",   default="sample",
                        choices=["sample", "greedy", "beam"],        help="Generation strategy")
    parser.add_argument("--beam-width", type=int,   default=4,       help="Beam width (strategy=beam only)")
    args = parser.parse_args()

    if not Path(args.checkpoint).exists():
        print(f"ERROR: Checkpoint not found: {args.checkpoint}")
        sys.exit(1)

    chat(args)
