# Tiny LLM — Starter Kit

A complete, modern LLM training codebase you can run on a free **T4 GPU** today and scale to **A100/H100** with a single line change.

---

## File Overview

| File | Purpose |
|------|---------|
| `config.py` | All hyperparameters + `ScalePreset` (tiny/small/medium) |
| `model.py` | GPT transformer — RoPE, RMSNorm, SwiGLU, GQA |
| `tokenizer.py` | BPE tokenizer (train from scratch or load pretrained) |
| `dataset.py` | JSONL data loader + HuggingFace swap-in hook |
| `train.py` | Training loop — checkpoints, resume, pretty progress |
| `evaluate.py` | Validation perplexity |
| `generate.py` | Sampling · greedy · beam search |
| `chat.py` | Interactive REPL for testing any checkpoint |
| `utils.py` | Checkpointing, seeding, formatting helpers |
| `dataset.jsonl` | 28 sample training examples (`{"text": "..."}` format) |

---

## Step 1 — Environment Setup

```bash
# Python 3.10+ recommended
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install tokenizers transformers rich
```

**Optional (for FlashAttention on A100/H100):**
```bash
pip install flash-attn --no-build-isolation
```

**On Google Colab / Kaggle (T4):** the `torch` with CUDA is already installed, just run:
```bash
pip install tokenizers rich
```

---

## Step 2 — Prepare Your Data

The training data lives in `dataset.jsonl`. Every line must be a JSON object with a `"text"` key:

```jsonl
{"text": "Your training text goes here."}
{"text": "Each line is one document or example."}
```

The 28 sample entries in `dataset.jsonl` are enough to verify the pipeline works. **For real training you need at least a few MB of text** (thousands of lines).

---

## Step 3 — Train a Tokenizer

```bash
python tokenizer.py --train --data dataset.jsonl --save tokenizer/ --vocab-size 32000
```

This creates `tokenizer/tokenizer.json`. Run this **once** before your first training run. If the tokenizer directory already exists, `train.py` will skip this step automatically.

---

## Step 4 — Start Training (T4)

```bash
python train.py
```

The model is set to the **tiny** preset in `config.py` (~15M params, context 512). This fits comfortably in a T4's 16 GB of VRAM.

**Training output looks like:**
```
[████████░░░░░░░░░░░░]  42.0%  step=  2100/5000  loss=3.1821  lr=3.00e-04  tok/s= 18,432  eta=4m12s
```

**Checkpoints** are saved automatically every 500 steps to `checkpoints/`. The last 3 are kept.

---

## Step 5 — Resume After Interruption

Just re-run the same command — it automatically finds and resumes from the latest checkpoint:

```bash
python train.py
# → Resuming from checkpoint: checkpoints/step_0002500.pt
# → Resumed at step 2500
```

No data is ever lost.

---

## Step 6 — Test with Chat

While training is in progress (or after), test any checkpoint:

```bash
python chat.py --checkpoint checkpoints/step_0001000.pt
```

Options:
```bash
# Greedy decoding (deterministic)
python chat.py --checkpoint checkpoints/step_0001000.pt --strategy greedy

# Beam search
python chat.py --checkpoint checkpoints/step_0001000.pt --strategy beam --beam-width 4

# Control randomness
python chat.py --checkpoint checkpoints/step_0001000.pt --temperature 0.7 --top-p 0.95

# Longer responses
python chat.py --checkpoint checkpoints/step_0001000.pt --max-new 300
```

In-chat commands: `/strategy sample`, `/temp 0.7`, `/topp 0.9`, `/quit`

---

## Step 7 — Scale Up to A100 / H100

### 7a. Switch the preset (one line)

Open `config.py` and change:
```python
PRESET = ScalePreset.tiny    # ← change to ScalePreset.small or ScalePreset.medium
```

| Preset | Params | Context | GPU |
|--------|--------|---------|-----|
| `tiny` | ~15M | 512 | T4 16 GB |
| `small` | ~125M | 1024 | A100 40 GB |
| `medium` | ~350M | 2048 | H100 80 GB |

Or pass it at runtime:
```bash
python train.py --preset small
```

### 7b. Enable FlashAttention-2

In `config.py`, set:
```python
# Inside ModelConfig defaults or your preset override:
use_flash_attn = True
```

Requires `pip install flash-attn --no-build-isolation` on the target machine.

### 7c. Enable torch.compile (A100/H100)

In `config.py`, set:
```python
# Inside TrainConfig or _TRAIN_PRESETS["small"]:
compile = True
```

The `small` and `medium` presets already set `compile=True` automatically.

### 7d. Switch to a HuggingFace dataset

In `dataset.py`, un-comment and fill in `get_hf_dataset()`, then call it from `train.py` instead of `make_dataloaders()`. Example dataset IDs:

```python
# High-quality web text (10B tokens):
dataset_id = "HuggingFaceFW/fineweb-edu"
subset     = "sample-10BT"

# Books:
dataset_id = "bookcorpus"

# Wikipedia:
dataset_id = "wikipedia"
subset     = "20231101.en"
```

Install: `pip install datasets`

---

## Scale-Up Checklist

- [ ] Change `PRESET` in `config.py` to `small` or `medium`
- [ ] Install `flash-attn` and set `use_flash_attn = True`
- [ ] `torch.compile = True` is already set in the preset
- [ ] Switch `data_path` in `TrainConfig` to your large dataset
- [ ] Un-comment and wire up `get_hf_dataset()` in `dataset.py`
- [ ] Increase `max_steps` (e.g. 50k→200k+)
- [ ] Consider multi-GPU: wrap model in `torch.nn.parallel.DistributedDataParallel`

---

## Notes on Multi-GPU (DDP)

For distributed training across multiple GPUs, wrap the training in `torchrun`:
```bash
torchrun --nproc_per_node=8 train.py --preset medium
```

You'll also need to add `DistributedDataParallel` and a `DistributedSampler` to `train.py`. See the [PyTorch DDP tutorial](https://pytorch.org/tutorials/intermediate/ddp_tutorial.html) for the exact changes.

---

## Architecture Reference

| Component | Choice | Why |
|-----------|--------|-----|
| Position encoding | RoPE | Better length generalization |
| Normalization | RMSNorm | Faster, simpler than LayerNorm |
| Activation | SwiGLU | Standard in Llama, Mistral, Gemma |
| Attention | GQA-ready | Reduces KV cache memory at scale |
| Attention kernel | `F.scaled_dot_product_attention` | Uses Flash-Attention under the hood in PyTorch ≥2.0 |
| Optimizer | AdamW + cosine decay | Standard for LLM training |
| Weight tying | embed ↔ lm_head | Reduces params, standard practice |
