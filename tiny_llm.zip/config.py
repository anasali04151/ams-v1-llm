from __future__ import annotations
from dataclasses import dataclass
from enum import Enum


class ScalePreset(str, Enum):
    tiny   = "tiny"    # T4  (free Colab / Kaggle) — ~15M params
    small  = "small"   # A100 40 GB               — ~125M params
    medium = "medium"  # H100 80 GB               — ~350M params


# ── One-line preset switch ─────────────────────────────────────────────────────
PRESET = ScalePreset.tiny          # ← change to ScalePreset.small / .medium


@dataclass
class ModelConfig:
    vocab_size:     int   = 32_000
    context_len:    int   = 512
    n_layers:       int   = 6
    n_heads:        int   = 6
    n_kv_heads:     int   = 6       # set < n_heads to enable GQA
    d_model:        int   = 384
    d_ff_mult:      float = 2.667   # hidden = int(d_model * d_ff_mult)  (SwiGLU rule)
    dropout:        float = 0.0
    use_flash_attn: bool  = False   # flip to True when flash-attn is installed


@dataclass
class TrainConfig:
    # ── Data ──────────────────────────────────────────────────────────────────
    data_path:      str   = "dataset.jsonl"
    tokenizer_path: str   = "tokenizer"      # directory with tokenizer.json
    val_split:      float = 0.05

    # ── Training ──────────────────────────────────────────────────────────────
    max_steps:      int   = 5_000
    batch_size:     int   = 16
    grad_accum:     int   = 1               # effective batch = batch_size * grad_accum
    lr:             float = 3e-4
    lr_min:         float = 1e-5
    warmup_steps:   int   = 100
    weight_decay:   float = 0.1
    grad_clip:      float = 1.0
    seed:           int   = 42

    # ── Logging & checkpoints ─────────────────────────────────────────────────
    log_interval:   int   = 10
    eval_interval:  int   = 500
    save_interval:  int   = 500
    checkpoint_dir: str   = "checkpoints"
    keep_last_n:    int   = 3               # how many recent checkpoints to keep

    # ── Hardware ──────────────────────────────────────────────────────────────
    device:         str   = "cuda"          # "cuda" | "cpu" | "mps"
    dtype:          str   = "bfloat16"      # "float32" | "float16" | "bfloat16"
    compile:        bool  = False           # torch.compile — True on A100/H100


# ── Preset overrides ──────────────────────────────────────────────────────────
_MODEL_PRESETS: dict[ScalePreset, dict] = {
    ScalePreset.tiny: dict(
        vocab_size=32_000, context_len=512,
        n_layers=6, n_heads=6, n_kv_heads=6, d_model=384,
    ),
    ScalePreset.small: dict(
        vocab_size=32_000, context_len=1024,
        n_layers=12, n_heads=12, n_kv_heads=4, d_model=768,
    ),
    ScalePreset.medium: dict(
        vocab_size=32_000, context_len=2048,
        n_layers=24, n_heads=16, n_kv_heads=4, d_model=1024,
    ),
}

_TRAIN_PRESETS: dict[ScalePreset, dict] = {
    ScalePreset.tiny:   dict(batch_size=16, grad_accum=1,  max_steps=5_000,   lr=3e-4),
    ScalePreset.small:  dict(batch_size=32, grad_accum=4,  max_steps=50_000,  lr=2e-4, compile=True),
    ScalePreset.medium: dict(batch_size=64, grad_accum=8,  max_steps=200_000, lr=1e-4, compile=True),
}


def get_config(preset: ScalePreset = PRESET) -> tuple[ModelConfig, TrainConfig]:
    """Return (ModelConfig, TrainConfig) with preset overrides applied."""
    # Start from dataclass defaults, then apply preset overrides
    model_cfg = ModelConfig(**_MODEL_PRESETS[preset])
    train_cfg = TrainConfig(**_TRAIN_PRESETS[preset])
    return model_cfg, train_cfg


# Validate that fields are correct primitive types (catches bugs at import time)
def _validate_config() -> None:
    m, t = get_config(PRESET)
    assert isinstance(t.data_path, str),      f"data_path must be str, got {type(t.data_path)}"
    assert isinstance(t.tokenizer_path, str), f"tokenizer_path must be str, got {type(t.tokenizer_path)}"
    assert isinstance(t.device, str),         f"device must be str, got {type(t.device)}"
    assert isinstance(t.dtype, str),          f"dtype must be str, got {type(t.dtype)}"
    assert isinstance(t.lr, float),           f"lr must be float, got {type(t.lr)}"
    assert isinstance(m.d_model, int),        f"d_model must be int, got {type(m.d_model)}"

_validate_config()

# Convenience singleton used by other modules
MODEL_CFG, TRAIN_CFG = get_config(PRESET)
