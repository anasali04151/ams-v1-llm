"""
Text generation strategies: greedy · top-p (nucleus) · beam search.
Importable by chat.py and usable standalone.
"""
from __future__ import annotations
import math
import torch
import torch.nn.functional as F


@torch.no_grad()
def generate(
    model:        torch.nn.Module,
    prompt_ids:   list[int] | torch.Tensor,
    max_new:      int   = 200,
    temperature:  float = 0.8,
    top_p:        float = 0.9,
    top_k:        int   = 0,          # 0 = disabled
    strategy:     str   = "sample",   # "sample" | "greedy" | "beam"
    beam_width:   int   = 4,          # used only when strategy="beam"
    eos_id:       int | None = None,
    device:       torch.device | str = "cpu",
) -> list[int]:
    """
    Generate tokens from a prompt.

    Returns a flat list of NEW token ids (not including the prompt).
    """
    device = torch.device(device) if isinstance(device, str) else device
    model.eval()

    if strategy == "beam":
        return _beam_search(model, prompt_ids, max_new, beam_width, eos_id, device)
    else:
        return _sample(model, prompt_ids, max_new, temperature, top_p, top_k,
                       greedy=(strategy == "greedy"), eos_id=eos_id, device=device)


# ── Sampling (greedy + top-p / top-k) ────────────────────────────────────────
def _sample(
    model, prompt_ids, max_new, temperature, top_p, top_k, greedy, eos_id, device
) -> list[int]:
    if isinstance(prompt_ids, torch.Tensor):
        ids = prompt_ids.clone().to(device)
    else:
        ids = torch.tensor(prompt_ids, dtype=torch.long, device=device)

    ids = ids.unsqueeze(0)          # (1, T)
    context_len = getattr(model, "cfg", None)
    ctx_len = context_len.context_len if context_len else 512

    generated: list[int] = []

    for _ in range(max_new):
        # Crop to context window
        ids_crop = ids[:, -ctx_len:]
        logits, _ = model(ids_crop)        # (1, T, V)
        next_logits = logits[0, -1, :]     # (V,)

        if greedy:
            next_id = next_logits.argmax().item()
        else:
            # Temperature
            if temperature != 1.0:
                next_logits = next_logits / max(temperature, 1e-8)

            # Top-k filter
            if top_k > 0:
                top_k_vals, _ = torch.topk(next_logits, top_k)
                next_logits[next_logits < top_k_vals[-1]] = -float("inf")

            # Top-p (nucleus) filter
            if top_p < 1.0:
                sorted_logits, sorted_idx = torch.sort(next_logits, descending=True)
                probs_sorted = F.softmax(sorted_logits, dim=-1)
                cum_probs    = probs_sorted.cumsum(dim=-1)
                # Remove tokens beyond the nucleus
                remove_mask = (cum_probs - probs_sorted) > top_p
                sorted_logits[remove_mask] = -float("inf")
                next_logits = torch.zeros_like(next_logits).scatter_(0, sorted_idx, sorted_logits)

            probs   = F.softmax(next_logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1).item()

        generated.append(int(next_id))
        ids = torch.cat([ids, torch.tensor([[next_id]], device=device)], dim=1)

        if eos_id is not None and next_id == eos_id:
            break

    return generated


# ── Beam search ───────────────────────────────────────────────────────────────
def _beam_search(model, prompt_ids, max_new, beam_width, eos_id, device) -> list[int]:
    if isinstance(prompt_ids, torch.Tensor):
        prompt = prompt_ids.clone().to(device)
    else:
        prompt = torch.tensor(prompt_ids, dtype=torch.long, device=device)

    ctx_len = getattr(getattr(model, "cfg", None), "context_len", 512)

    # Each beam: (score, token_ids_list)
    beams: list[tuple[float, list[int]]] = [(0.0, prompt.tolist())]
    completed: list[tuple[float, list[int]]] = []

    for _ in range(max_new):
        all_candidates: list[tuple[float, list[int]]] = []

        for score, seq in beams:
            if eos_id is not None and seq[-1] == eos_id:
                completed.append((score, seq))
                continue

            ids = torch.tensor(seq[-ctx_len:], dtype=torch.long, device=device).unsqueeze(0)
            with torch.no_grad():
                logits, _ = model(ids)
            log_probs = F.log_softmax(logits[0, -1, :], dim=-1)
            top_lp, top_ids = torch.topk(log_probs, beam_width)

            for lp, tid in zip(top_lp.tolist(), top_ids.tolist()):
                all_candidates.append((score + lp, seq + [tid]))

        # Keep top beams
        all_candidates.sort(key=lambda x: x[0], reverse=True)
        beams = all_candidates[:beam_width]

        if not beams:
            break

    # Pick best completed or best current beam
    best = (completed + beams)
    best.sort(key=lambda x: x[0], reverse=True)
    best_seq = best[0][1] if best else prompt.tolist()

    prompt_len = len(prompt_ids) if not isinstance(prompt_ids, torch.Tensor) else prompt_ids.numel()
    return best_seq[prompt_len:]
