"""
Tiny LLM — GPT-style transformer
Modern stack: RoPE · RMSNorm · SwiGLU · GQA-ready · FlashAttention-2 toggle
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from config import ModelConfig


# ── RMS Norm ──────────────────────────────────────────────────────────────────
class RMSNorm(nn.Module):
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(d))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        norm = x.float().pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return (x.float() * norm).type_as(x) * self.weight


# ── Rotary Positional Embedding ───────────────────────────────────────────────
def precompute_rope(head_dim: int, max_len: int, base: float = 10_000.0,
                    device: torch.device | None = None) -> tuple[torch.Tensor, torch.Tensor]:
    theta = 1.0 / (base ** (torch.arange(0, head_dim, 2, device=device).float() / head_dim))
    pos   = torch.arange(max_len, device=device).float()
    freqs = torch.outer(pos, theta)          # (max_len, head_dim//2)
    cos   = torch.cos(freqs)
    sin   = torch.sin(freqs)
    return cos, sin


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    # x: (B, H, T, head_dim)
    T = x.size(2)
    cos = cos[:T].unsqueeze(0).unsqueeze(0)   # (1,1,T,head_dim//2)
    sin = sin[:T].unsqueeze(0).unsqueeze(0)
    x1, x2 = x[..., ::2], x[..., 1::2]
    rot_x = torch.stack([x1 * cos - x2 * sin, x1 * sin + x2 * cos], dim=-1)
    return rot_x.flatten(-2)


# ── SwiGLU MLP ────────────────────────────────────────────────────────────────
class MLP(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        hidden = int(cfg.d_model * cfg.d_ff_mult)
        # round to multiple of 64 for efficiency
        hidden = (hidden + 63) // 64 * 64
        self.gate = nn.Linear(cfg.d_model, hidden, bias=False)
        self.up   = nn.Linear(cfg.d_model, hidden, bias=False)
        self.down = nn.Linear(hidden, cfg.d_model, bias=False)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.down(F.silu(self.gate(x)) * self.up(x)))


# ── Grouped Query Attention (GQA) ────────────────────────────────────────────
class Attention(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        assert cfg.d_model % cfg.n_heads == 0
        self.n_heads    = cfg.n_heads
        self.n_kv_heads = cfg.n_kv_heads
        self.head_dim   = cfg.d_model // cfg.n_heads
        self.groups     = cfg.n_heads // cfg.n_kv_heads   # queries per KV head
        self.use_flash  = cfg.use_flash_attn
        self.scale      = self.head_dim ** -0.5
        self.dropout    = cfg.dropout

        self.q_proj  = nn.Linear(cfg.d_model, cfg.n_heads    * self.head_dim, bias=False)
        self.k_proj  = nn.Linear(cfg.d_model, cfg.n_kv_heads * self.head_dim, bias=False)
        self.v_proj  = nn.Linear(cfg.d_model, cfg.n_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(cfg.n_heads * self.head_dim, cfg.d_model,   bias=False)
        self.attn_drop = nn.Dropout(cfg.dropout)

    def forward(
        self,
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
    ) -> torch.Tensor:
        B, T, C = x.shape

        q = self.q_proj(x).view(B, T, self.n_heads,    self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)

        q = apply_rope(q, cos, sin)
        k = apply_rope(k, cos, sin)

        # Expand KV heads → match Q heads (GQA)
        if self.groups > 1:
            k = k.repeat_interleave(self.groups, dim=1)
            v = v.repeat_interleave(self.groups, dim=1)

        if self.use_flash:
            # Requires: pip install flash-attn --no-build-isolation
            from flash_attn import flash_attn_func          # type: ignore[import]
            # flash_attn expects (B, T, H, head_dim)
            q = q.transpose(1, 2)
            k = k.transpose(1, 2)
            v = v.transpose(1, 2)
            out = flash_attn_func(q, k, v, dropout_p=self.dropout if self.training else 0.0,
                                  causal=True)
            out = out.reshape(B, T, -1)
        else:
            # Standard scaled dot-product attention (uses Flash-Attention kernel in PyTorch ≥2.0)
            out = F.scaled_dot_product_attention(
                q, k, v,
                dropout_p=self.dropout if self.training else 0.0,
                is_causal=True,
            )
            out = out.transpose(1, 2).contiguous().view(B, T, -1)

        return self.out_proj(out)


# ── Transformer Block ─────────────────────────────────────────────────────────
class Block(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.norm1 = RMSNorm(cfg.d_model)
        self.attn  = Attention(cfg)
        self.norm2 = RMSNorm(cfg.d_model)
        self.mlp   = MLP(cfg)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x), cos, sin)
        x = x + self.mlp(self.norm2(x))
        return x


# ── Top-level GPT model ───────────────────────────────────────────────────────
class GPT(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg
        self.embed   = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.drop    = nn.Dropout(cfg.dropout)
        self.blocks  = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layers)])
        self.norm    = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)

        # Weight tying (embedding ↔ lm_head) — standard best practice
        self.lm_head.weight = self.embed.weight

        # Pre-compute RoPE buffers (not model params)
        head_dim = cfg.d_model // cfg.n_heads
        cos, sin = precompute_rope(head_dim, cfg.context_len)
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)

        self.apply(self._init_weights)

    # ── Weight initialisation (GPT-2 style) ───────────────────────────────────
    def _init_weights(self, module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            std = 0.02
            if hasattr(module, "_is_residual"):
                std /= math.sqrt(2 * self.cfg.n_layers)
            nn.init.normal_(module.weight, mean=0.0, std=std)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

        # Mark residual projections for scaled init
        for name in ("out_proj", "down"):
            if hasattr(module, name):
                getattr(module, name)._is_residual = True   # type: ignore[attr-defined]

    # ── Forward ───────────────────────────────────────────────────────────────
    def forward(
        self,
        idx: torch.Tensor,
        targets: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        B, T = idx.shape
        assert T <= self.cfg.context_len, f"Sequence too long: {T} > {self.cfg.context_len}"

        x   = self.drop(self.embed(idx))
        cos = self.rope_cos[:T]
        sin = self.rope_sin[:T]

        for block in self.blocks:
            x = block(x, cos, sin)

        x    = self.norm(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))

        return logits, loss

    # ── Parameter count ───────────────────────────────────────────────────────
    def num_params(self, non_embedding: bool = True) -> int:
        n = sum(p.numel() for p in self.parameters())
        if non_embedding:
            n -= self.embed.weight.numel()
        return n
