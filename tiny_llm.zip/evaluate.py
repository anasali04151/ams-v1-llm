"""
Evaluation — computes validation perplexity.
Called from train.py every eval_interval steps.
"""
from __future__ import annotations
import math
import torch
from torch.utils.data import DataLoader
from utils import get_autocast_ctx


@torch.no_grad()
def evaluate(
    model:      torch.nn.Module,
    val_loader: DataLoader,
    device:     torch.device,
    dtype_str:  str = "bfloat16",
    max_batches: int | None = None,
) -> tuple[float, float]:
    """
    Returns (avg_loss, perplexity) on the validation set.
    `max_batches` caps evaluation for speed during training.
    """
    model.eval()
    total_loss  = 0.0
    total_tokens = 0
    n_batches   = 0

    ctx = get_autocast_ctx(device, dtype_str)
    with ctx:
        for i, (x, y) in enumerate(val_loader):
            if max_batches and i >= max_batches:
                break
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            _, loss = model(x, y)
            total_loss   += loss.item() * x.numel()
            total_tokens += x.numel()
            n_batches    += 1

    if total_tokens == 0:
        return float("inf"), float("inf")

    avg_loss   = total_loss / total_tokens
    perplexity = math.exp(min(avg_loss, 20))   # cap at e^20 ≈ 485M to avoid overflow
    model.train()
    return avg_loss, perplexity
