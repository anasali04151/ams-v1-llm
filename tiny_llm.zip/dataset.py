"""
Dataset utilities for the tiny LLM.

Local training  → reads dataset.jsonl
Big-GPU training → swap in get_hf_dataset() pointing to any HuggingFace dataset
"""
from __future__ import annotations
import json
import random
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader, random_split

from tokenizer import Tokenizer


# ── Local JSONL Dataset ───────────────────────────────────────────────────────
class TextDataset(Dataset):
    """
    Reads a .jsonl file where each line has {"text": "..."}.
    Tokenises all texts, concatenates them into one long token stream,
    then creates fixed-length chunks of size `context_len`.
    """
    def __init__(
        self,
        data_path:   str | Path,
        tokenizer:   Tokenizer,
        context_len: int,
        split:       str = "train",    # "train" | "val"
        val_split:   float = 0.05,
        seed:        int   = 42,
    ):
        data_path = Path(data_path)
        tokens = self._load_and_tokenize(data_path, tokenizer)

        # Train / val split
        n_val   = max(1, int(len(tokens) * val_split))
        n_train = len(tokens) - n_val
        rng     = random.Random(seed)
        # Shuffle at document boundaries instead of token boundaries
        # (already concatenated, so we just cut)
        if split == "val":
            tokens = tokens[n_train:]
        else:
            tokens = tokens[:n_train]

        self.tokens      = torch.tensor(tokens, dtype=torch.long)
        self.context_len = context_len
        self.n_chunks    = max(0, (len(self.tokens) - 1) // context_len)

    def _load_and_tokenize(self, path: Path, tok: Tokenizer) -> list[int]:
        all_ids: list[int] = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj  = json.loads(line)
                text = obj.get("text", "")
                if text:
                    all_ids.extend(tok.encode(text, add_special_tokens=True))
        if not all_ids:
            raise ValueError(f"No tokens found in {path}. Check your dataset.jsonl.")
        return all_ids

    def __len__(self) -> int:
        return self.n_chunks

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        start  = idx * self.context_len
        end    = start + self.context_len
        x = self.tokens[start:end]
        y = self.tokens[start + 1:end + 1]
        return x, y


class EpochShuffleSampler(torch.utils.data.Sampler):
    """
    Deterministic per-epoch shuffled sampler.
    Shuffles with seed=(base_seed + epoch), so any epoch can be reproduced
    by setting the epoch number — enabling exact checkpoint resume.
    """
    def __init__(self, n: int, base_seed: int = 42, epoch: int = 0):
        self.n         = n
        self.base_seed = base_seed
        self.epoch     = epoch

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def __iter__(self):
        g = torch.Generator()
        g.manual_seed(self.base_seed + self.epoch)
        yield from torch.randperm(self.n, generator=g).tolist()

    def __len__(self) -> int:
        return self.n


def make_dataloaders(
    data_path:   str,
    tokenizer:   Tokenizer,
    context_len: int,
    batch_size:  int,
    val_split:   float = 0.05,
    seed:        int   = 42,
    num_workers: int   = 0,
) -> tuple[DataLoader, DataLoader, "EpochShuffleSampler"]:
    train_ds = TextDataset(data_path, tokenizer, context_len, "train", val_split, seed)
    val_ds   = TextDataset(data_path, tokenizer, context_len, "val",   val_split, seed)

    print(f"Dataset  → train: {len(train_ds):,} chunks  |  val: {len(val_ds):,} chunks")

    train_sampler = EpochShuffleSampler(n=len(train_ds), base_seed=seed, epoch=0)
    train_dl = DataLoader(
        train_ds, batch_size=batch_size, sampler=train_sampler,
        num_workers=num_workers, pin_memory=True, drop_last=True,
    )
    val_dl = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True, drop_last=False,
    )
    return train_dl, val_dl, train_sampler


# ── HuggingFace Dataset (uncomment when switching to big-GPU run) ─────────────
# def get_hf_dataset(
#     dataset_id:  str = "HuggingFaceFW/fineweb-edu",
#     subset:      str = "sample-10BT",
#     tokenizer:   Tokenizer | None = None,
#     context_len: int = 1024,
#     batch_size:  int = 32,
#     seed:        int = 42,
# ) -> tuple[DataLoader, DataLoader]:
#     """
#     Swap this in for make_dataloaders() for large-scale training.
#     Requires: pip install datasets
#     """
#     from datasets import load_dataset                        # type: ignore
#     ds = load_dataset(dataset_id, subset, split="train", streaming=True)
#     # ... tokenize & chunk
#     # See README.md §5 for full implementation notes.
#     raise NotImplementedError("Wire up streaming dataset here.")
