"""
Utility helpers: checkpointing, seeding, formatting.
"""
from __future__ import annotations
import os
import random
import glob
import tempfile
import shutil
from pathlib import Path

import torch
import numpy as np


# ── Reproducibility ───────────────────────────────────────────────────────────
def seed_everything(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ── Parameter counting ────────────────────────────────────────────────────────
def count_params(model: torch.nn.Module, non_embedding: bool = True) -> int:
    if hasattr(model, "num_params"):
        return model.num_params(non_embedding)
    return sum(p.numel() for p in model.parameters())


def human_size(n: int) -> str:
    for unit in ("", "K", "M", "B", "T"):
        if abs(n) < 1_000:
            return f"{n:.1f}{unit}"
        n /= 1_000
    return f"{n:.1f}P"


# ── Number formatting ─────────────────────────────────────────────────────────
def fmt_num(n: float, decimals: int = 4) -> str:
    return f"{n:.{decimals}f}"


def fmt_time(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m"


# ── Checkpoint helpers ────────────────────────────────────────────────────────
def save_rng_state() -> dict:
    """Capture RNG state for all active generators."""
    state = {
        "python": random.getstate(),
        "numpy":  np.random.get_state(),
        "torch":  torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state_all()
    return state


def restore_rng_state(state: dict) -> None:
    """Restore RNG state saved by save_rng_state()."""
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if "cuda" in state and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state["cuda"])


def save_checkpoint(
    model:      torch.nn.Module,
    optimizer:  torch.optim.Optimizer,
    scheduler,
    step:       int,
    train_loss: float,
    val_loss:   float | None,
    cfg_model,
    cfg_train,
    checkpoint_dir: str | Path,
    keep_last_n: int = 3,
    extra:      dict | None = None,
) -> Path:
    """
    Atomically write a checkpoint using a temp file + rename.
    - Saves full RNG state (torch/cuda/numpy/python) for exact resume.
    - Saves model via unwrap_model() so torch.compile() checkpoints load cleanly.
    - `extra` dict is merged into the payload (used for data_epoch, batch_in_epoch).
    """
    ckpt_dir = Path(checkpoint_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    final_path = ckpt_dir / f"step_{step:07d}.pt"

    payload = {
        "step":       step,
        "model":      unwrap_model(model).state_dict(),   # always save unwrapped
        "optimizer":  optimizer.state_dict(),
        "scheduler":  scheduler.state_dict() if scheduler is not None else None,
        "train_loss": train_loss,
        "val_loss":   val_loss,
        "model_cfg":  cfg_model.__dict__,
        "train_cfg":  cfg_train.__dict__,
        "rng_state":  save_rng_state(),
    }
    if extra:
        payload.update(extra)

    # Write to a temp file first, then atomically rename
    tmp_fd, tmp_path = tempfile.mkstemp(dir=ckpt_dir, suffix=".tmp")
    try:
        os.close(tmp_fd)
        torch.save(payload, tmp_path)
        shutil.move(tmp_path, final_path)
    except Exception:
        os.unlink(tmp_path)
        raise

    # Prune old checkpoints
    _prune_checkpoints(ckpt_dir, keep_last_n)
    return final_path


def load_checkpoint(path: str | Path, device: str = "cpu") -> dict:
    """Load a checkpoint dict from disk."""
    return torch.load(str(path), map_location=device, weights_only=False)


def find_latest_checkpoint(checkpoint_dir: str | Path) -> Path | None:
    """Return the most recent step_*.pt file, or None if directory is empty."""
    ckpt_dir = Path(checkpoint_dir)
    if not ckpt_dir.exists():
        return None
    checkpoints = sorted(ckpt_dir.glob("step_*.pt"))
    return checkpoints[-1] if checkpoints else None


def _prune_checkpoints(ckpt_dir: Path, keep_last_n: int) -> None:
    checkpoints = sorted(ckpt_dir.glob("step_*.pt"))
    for old in checkpoints[:-keep_last_n]:
        old.unlink(missing_ok=True)


# ── Device helpers ────────────────────────────────────────────────────────────
def get_device(device_str: str) -> torch.device:
    if device_str == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    if device_str == "mps" and torch.backends.mps.is_available():
        return torch.device("mps")
    if device_str != "cpu":
        print(f"[warn] Device '{device_str}' not available, falling back to CPU.")
    return torch.device("cpu")


def resolve_dtype(dtype_str: str, device: torch.device) -> torch.dtype:
    """
    Resolve dtype string to a torch.dtype, with hardware safety checks.
    - bfloat16 requires Ampere+ (A100, H100, RTX 30xx+). Falls back to float16 on T4.
    - float16 works on T4 and newer.
    - float32 always works.
    """
    if dtype_str == "bfloat16":
        if device.type == "cuda" and not torch.cuda.is_bf16_supported():
            print("[warn] BF16 not supported on this GPU (T4?). Falling back to float16.")
            return torch.float16
        return torch.bfloat16
    if dtype_str == "float16":
        return torch.float16
    return torch.float32


def get_autocast_ctx(device: torch.device, dtype_str: str):
    """Return an autocast context manager for mixed precision."""
    if device.type == "cpu":
        return torch.amp.autocast("cpu", enabled=False)
    dtype = resolve_dtype(dtype_str, device)
    return torch.amp.autocast(device.type, dtype=dtype)


def unwrap_model(model: torch.nn.Module) -> torch.nn.Module:
    """
    Unwrap a torch.compile()'d model to get the original Module.
    Compiled models store the original under ._orig_mod.
    Always use this before calling state_dict() for checkpoint saving.
    """
    return getattr(model, "_orig_mod", model)
