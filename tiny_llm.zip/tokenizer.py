"""
Tokenizer wrapper around HuggingFace `tokenizers` (BPE).

Usage
-----
# Train a new tokenizer from your dataset.jsonl:
    python tokenizer.py --train --data dataset.jsonl --save tokenizer/

# Load an existing tokenizer:
    from tokenizer import Tokenizer
    tok = Tokenizer.load("tokenizer/")
    ids = tok.encode("Hello world")
    text = tok.decode(ids)
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from tokenizers import Tokenizer as HFTokenizer          # pip install tokenizers
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import ByteLevel
from tokenizers.decoders import ByteLevel as ByteLevelDecoder


SPECIAL_TOKENS = ["<pad>", "<unk>", "<bos>", "<eos>"]


class Tokenizer:
    def __init__(self, hf_tok: HFTokenizer):
        self._tok = hf_tok
        self.pad_id = hf_tok.token_to_id("<pad>")
        self.unk_id = hf_tok.token_to_id("<unk>")
        self.bos_id = hf_tok.token_to_id("<bos>")
        self.eos_id = hf_tok.token_to_id("<eos>")

    # ── Encode / Decode ───────────────────────────────────────────────────────
    def encode(self, text: str, add_special_tokens: bool = True) -> list[int]:
        """Tokenise text. Special tokens are added only here — not by the tokenizer internals."""
        enc = self._tok.encode(text)
        ids = enc.ids
        if add_special_tokens:
            ids = [self.bos_id] + ids + [self.eos_id]
        return ids

    def decode(self, ids: list[int], skip_special_tokens: bool = True) -> str:
        if skip_special_tokens:
            special = {self.pad_id, self.bos_id, self.eos_id}
            ids = [i for i in ids if i not in special]
        return self._tok.decode(ids)

    @property
    def vocab_size(self) -> int:
        return self._tok.get_vocab_size()

    # ── Persistence ───────────────────────────────────────────────────────────
    def save(self, directory: str | Path) -> None:
        path = Path(directory)
        path.mkdir(parents=True, exist_ok=True)
        self._tok.save(str(path / "tokenizer.json"))
        print(f"Tokenizer saved → {path}/tokenizer.json  (vocab_size={self.vocab_size})")

    @classmethod
    def load(cls, directory: str | Path) -> "Tokenizer":
        path = Path(directory) / "tokenizer.json"
        if not path.exists():
            raise FileNotFoundError(
                f"Tokenizer not found at {path}. "
                "Run: python tokenizer.py --train --data dataset.jsonl --save tokenizer/"
            )
        hf_tok = HFTokenizer.from_file(str(path))
        return cls(hf_tok)

    # ── Train from scratch ────────────────────────────────────────────────────
    @classmethod
    def train(
        cls,
        data_path: str | Path,
        vocab_size: int = 32_000,
        save_dir:  str | Path = "tokenizer",
        min_frequency: int = 2,
    ) -> "Tokenizer":
        texts = list(_iter_texts(data_path))

        hf_tok = HFTokenizer(BPE(unk_token="<unk>"))
        hf_tok.pre_tokenizer = ByteLevel(add_prefix_space=False)
        hf_tok.decoder       = ByteLevelDecoder()
        # NOTE: No post-processor — special tokens are added manually in encode()
        # to avoid double-application.

        trainer = BpeTrainer(
            vocab_size=vocab_size,
            min_frequency=min_frequency,
            special_tokens=SPECIAL_TOKENS,
            show_progress=True,
        )
        hf_tok.train_from_iterator(texts, trainer=trainer)

        tok = cls(hf_tok)
        tok.save(save_dir)
        return tok


def _iter_texts(data_path: str | Path):
    """Yield 'text' fields from a .jsonl file."""
    with open(data_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                obj = json.loads(line)
                yield obj.get("text", "")


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train or inspect the tokenizer")
    parser.add_argument("--train",  action="store_true")
    parser.add_argument("--data",   default="dataset.jsonl")
    parser.add_argument("--save",   default="tokenizer")
    parser.add_argument("--vocab-size", type=int, default=32_000)
    parser.add_argument("--test",   default="Hello, world! This is a test.")
    args = parser.parse_args()

    if args.train:
        tok = Tokenizer.train(args.data, vocab_size=args.vocab_size, save_dir=args.save)
    else:
        tok = Tokenizer.load(args.save)

    ids   = tok.encode(args.test)
    back  = tok.decode(ids)
    print(f"\nTest string : {args.test!r}")
    print(f"Encoded     : {ids}")
    print(f"Decoded     : {back!r}")
    print(f"Vocab size  : {tok.vocab_size}")
