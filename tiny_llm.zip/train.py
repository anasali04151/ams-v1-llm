"""
Training entry point.

Features:
  · Auto-resume: exact position — model, optimizer, RNG, and dataloader epoch/offset
  · Atomic checkpoint saves (never corrupt on interruption)
  · Cosine LR schedule with linear warmup
  · Gradient accumulation + gradient clipping
  · Auto-detect BF16 support (T4 → float16 fallback)
  · torch.compile portability — saves unwrapped state_dict
  · Beautiful single-line progress via rich (falls back to plain print)
"""
from __future__ import annotations
import sys
import time
import argparse
from pathlib import Path

import torch

from config import MODEL_CFG, TRAIN_CFG, get_config, ScalePreset
from model import GPT
from tokenizer import Tokenizer
from dataset import make_dataloaders, EpochShuffleSampler
from evaluate import evaluate
from utils import (
    seed_everything, count_params, human_size, fmt_time,
    save_checkpoint, load_checkpoint, find_latest_checkpoint,
    get_device, get_autocast_ctx, resolve_dtype, restore_rng_state, unwrap_model,
)

# ── rich for pretty output ─────────────────────────────────────────────────────
try:
    from rich.console import Console
    _HAS_RICH = True
except ImportError:
    _HAS_RICH = False


def _print_step(
    step: int, max_steps: int,
    loss: float, lr: float,
    tok_per_sec: float, eta_sec: float,
    val_loss: float | None = None,
    console=None,
) -> None:
    pct      = 100 * step / max_steps
    bar_w    = 20
    filled   = int(bar_w * step / max_steps)
    bar      = "█" * filled + "░" * (bar_w - filled)
    val_str  = f"  val_ppl={2**val_loss:.2f}" if val_loss is not None else ""

    line = (
        f"[{bar}] {pct:5.1f}%  "
        f"step={step:>6}/{max_steps}  "
        f"loss={loss:.4f}  "
        f"lr={lr:.2e}  "
        f"tok/s={tok_per_sec:>7,.0f}  "
        f"eta={fmt_time(eta_sec)}"
        f"{val_str}"
    )
    if _HAS_RICH and console:
        console.print(line, highlight=False)
    else:
        print(f"\r{line}", end="", flush=True)


# ── LR schedule: linear warmup + cosine decay ────────────────────────────────
def get_lr(step: int, warmup: int, max_steps: int, lr_max: float, lr_min: float) -> float:
    import math
    if step < warmup:
        return lr_max * step / max(1, warmup)
    progress = (step - warmup) / max(1, max_steps - warmup)
    return lr_min + 0.5 * (lr_max - lr_min) * (1 + math.cos(math.pi * progress))


# ── Main training loop ────────────────────────────────────────────────────────
def train(preset: str | None = None) -> None:
    if preset:
        model_cfg, train_cfg = get_config(ScalePreset(preset))
    else:
        model_cfg, train_cfg = MODEL_CFG, TRAIN_CFG

    seed_everything(train_cfg.seed)
    device = get_device(train_cfg.device)

    # ── Tokenizer ─────────────────────────────────────────────────────────────
    tok_path = Path(train_cfg.tokenizer_path)
    if not (tok_path / "tokenizer.json").exists():
        print(f"Tokenizer not found at {tok_path}. Training from {train_cfg.data_path} ...")
        Tokenizer.train(train_cfg.data_path, vocab_size=model_cfg.vocab_size, save_dir=tok_path)
    tokenizer = Tokenizer.load(tok_path)
    model_cfg.vocab_size = tokenizer.vocab_size

    # ── Data ──────────────────────────────────────────────────────────────────
    train_dl, val_dl, train_sampler = make_dataloaders(
        data_path=train_cfg.data_path,
        tokenizer=tokenizer,
        context_len=model_cfg.context_len,
        batch_size=train_cfg.batch_size,
        val_split=train_cfg.val_split,
        seed=train_cfg.seed,
    )
    if len(train_dl) == 0:
        print("ERROR: Not enough data for even one batch. Add more text to dataset.jsonl.")
        sys.exit(1)

    steps_per_epoch = len(train_dl)   # number of complete batches per epoch

    # ── Model ─────────────────────────────────────────────────────────────────
    model = GPT(model_cfg).to(device)
    if train_cfg.compile and hasattr(torch, "compile"):
        print("Compiling model with torch.compile() ...")
        model = torch.compile(model)   # type: ignore[assignment]

    n_params = count_params(model)
    # Resolve actual dtype (handles T4 → float16 fallback)
    actual_dtype = resolve_dtype(train_cfg.dtype, device)
    print(
        f"\nModel   → {human_size(n_params)} params  |  "
        f"device={device}  dtype={actual_dtype}  |  "
        f"layers={model_cfg.n_layers}  heads={model_cfg.n_heads}  d_model={model_cfg.d_model}"
    )

    # ── Optimiser ─────────────────────────────────────────────────────────────
    decay_params    = [p for n, p in model.named_parameters() if p.dim() >= 2]
    no_decay_params = [p for n, p in model.named_parameters() if p.dim() < 2]
    optimizer = torch.optim.AdamW(
        [
            {"params": decay_params,    "weight_decay": train_cfg.weight_decay},
            {"params": no_decay_params, "weight_decay": 0.0},
        ],
        lr=train_cfg.lr,
        betas=(0.9, 0.95),
        eps=1e-8,
    )
    # GradScaler only for float16 (BF16 doesn't need scaling)
    use_scaler = (actual_dtype == torch.float16 and device.type == "cuda")
    scaler = torch.cuda.GradScaler(enabled=use_scaler)

    # ── Auto-resume ───────────────────────────────────────────────────────────
    start_step     = 0
    data_epoch     = 0     # which shuffle epoch we're in
    batch_in_epoch = 0     # how many batches consumed in current epoch (for skip)
    val_loss_last: float | None = None

    latest_ckpt = find_latest_checkpoint(train_cfg.checkpoint_dir)
    if latest_ckpt:
        print(f"Resuming from checkpoint: {latest_ckpt}")
        ckpt = load_checkpoint(latest_ckpt, device=str(device))
        unwrap_model(model).load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_step     = ckpt["step"]
        data_epoch     = ckpt.get("data_epoch", 0)
        batch_in_epoch = ckpt.get("batch_in_epoch", 0)
        val_loss_last  = ckpt.get("val_loss")
        # Restore full RNG state
        if "rng_state" in ckpt:
            restore_rng_state(ckpt["rng_state"])
        print(f"Resumed at step {start_step}  (epoch={data_epoch}, batch_in_epoch={batch_in_epoch})")
    else:
        print(f"Starting fresh training for {train_cfg.max_steps:,} steps.")

    # ── Build a resumable data iterator ───────────────────────────────────────
    train_sampler.set_epoch(data_epoch)
    data_iter      = iter(train_dl)

    # Skip already-consumed batches in the current epoch (exact resume)
    if batch_in_epoch > 0:
        skip = min(batch_in_epoch, steps_per_epoch - 1)
        print(f"  Fast-forwarding {skip} batches in epoch {data_epoch} ...")
        for _ in range(skip):
            try:
                next(data_iter)
            except StopIteration:
                break

    # ── Training loop ─────────────────────────────────────────────────────────
    console      = Console() if _HAS_RICH else None
    ctx          = get_autocast_ctx(device, train_cfg.dtype)
    model.train()
    step         = start_step
    running_loss = 0.0
    t0           = time.perf_counter()
    tokens_seen  = 0

    print(f"\nTraining started. Checkpoints → {train_cfg.checkpoint_dir}/\n")

    while step < train_cfg.max_steps:
        lr = get_lr(step, train_cfg.warmup_steps, train_cfg.max_steps,
                    train_cfg.lr, train_cfg.lr_min)
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        accum_loss = 0.0

        for _micro in range(train_cfg.grad_accum):
            try:
                x, y = next(data_iter)
                batch_in_epoch += 1
            except StopIteration:
                # New epoch — advance epoch counter, rebuild iterator
                data_epoch    += 1
                batch_in_epoch = 0
                train_sampler.set_epoch(data_epoch)
                data_iter = iter(train_dl)
                x, y = next(data_iter)
                batch_in_epoch += 1

            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            with ctx:
                _, loss = model(x, y)
                loss    = loss / train_cfg.grad_accum

            scaler.scale(loss).backward()
            accum_loss  += loss.item()
            tokens_seen += x.numel()

        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), train_cfg.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        step += 1
        running_loss = 0.9 * running_loss + 0.1 * accum_loss if step > 1 else accum_loss

        # ── Logging ───────────────────────────────────────────────────────────
        if step % train_cfg.log_interval == 0:
            elapsed   = time.perf_counter() - t0
            tok_per_s = tokens_seen / elapsed if elapsed > 0 else 0
            eta       = elapsed / step * (train_cfg.max_steps - step)
            _print_step(step, train_cfg.max_steps, running_loss, lr,
                        tok_per_s, eta, val_loss_last, console)

        # ── Evaluation ────────────────────────────────────────────────────────
        if step % train_cfg.eval_interval == 0:
            val_loss, _ = evaluate(model, val_dl, device, train_cfg.dtype, max_batches=50)
            val_loss_last = val_loss
            elapsed   = time.perf_counter() - t0
            tok_per_s = tokens_seen / elapsed if elapsed > 0 else 0
            eta       = elapsed / step * (train_cfg.max_steps - step)
            _print_step(step, train_cfg.max_steps, running_loss, lr,
                        tok_per_s, eta, val_loss, console)
            print()

        # ── Checkpoint ────────────────────────────────────────────────────────
        if step % train_cfg.save_interval == 0:
            ckpt_path = save_checkpoint(
                model, optimizer, None, step, running_loss, val_loss_last,
                model_cfg, train_cfg,
                train_cfg.checkpoint_dir, train_cfg.keep_last_n,
                extra={"data_epoch": data_epoch, "batch_in_epoch": batch_in_epoch},
            )
            print(f"  ✓ Saved → {ckpt_path}")

    # ── Final checkpoint ──────────────────────────────────────────────────────
    final_path = save_checkpoint(
        model, optimizer, None, step, running_loss, None,
        model_cfg, train_cfg,
        train_cfg.checkpoint_dir, keep_last_n=999,
        extra={"data_epoch": data_epoch, "batch_in_epoch": batch_in_epoch},
    )
    print(f"\nTraining complete!  Final checkpoint → {final_path}")


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train the tiny LLM")
    parser.add_argument("--preset", choices=["tiny", "small", "medium"],
                        default=None, help="Scale preset (overrides config.py PRESET)")
    args = parser.parse_args()
    train(args.preset)
